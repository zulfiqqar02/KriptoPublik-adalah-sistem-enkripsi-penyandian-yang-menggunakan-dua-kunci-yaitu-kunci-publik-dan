#include "dialog_2.h"
#include "ui_dialog_2.h"

Dialog_2::Dialog_2(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Dialog_2)
{
    ui->setupUi(this);
}

Dialog_2::~Dialog_2()
{
    delete ui;
}

//Digunakan untuk menghitung kunci publik pengirim
void Dialog_2::on_hitung_publik_clicked()
{
    long int total = 1;
    long int pemodulo, pengirim;
    int angka1 = ui->txt_angka1->text().toInt();
    int angka2 = ui->txt_angka2->text().toInt();
    for (int i = 1; i <= angka2; i++) {
                total = total * angka1;
            }
    pemodulo = ui->txt_pemodulo->text().toInt();
    pengirim = total % pemodulo;
    ui->txt_pengirim->setText(QString::number(pengirim));
}

//Digunakan untuk menghitung kunci enkripsi
void Dialog_2::on_hitung_key_clicked()
{
    long int penerima,key,pemodulo;
    long int enkrip = 1;
    int angka2 = ui->txt_angka2->text().toInt();
    penerima = ui->txt_penerima->text().toInt();
    pemodulo = ui->txt_pemodulo->text().toInt();


    for (int j = 1; j<= angka2; j++) {
         enkrip = enkrip * penerima;
    }

    key = enkrip % pemodulo;
    ui->txt_key->setText(QString::number(key));
}

//Digunakan untuk konversi dari karakter "pesan" ke ASCII
void Dialog_2::on_konversi_clicked()
{
    QString pesan = ui->txt_pesan->text();
    QStringList numberString;
    for (const auto character:pesan){
        numberString << QString::number(character.unicode());
    }
    QString HexStrData = numberString.join(" ");
    ui->txt_ascii->setText(HexStrData);

}


//Digunakan untuk proses XOR antara pesan (ASCII) dengan Kunci enkripsinya
void Dialog_2::on_btn_enkrip_clicked()
{
    long int chiper =1;
    int key = ui->txt_key->text().toInt();
    int ascii = ui->txt_ascii->text().toInt();

    chiper = ascii ^ key;
    ui->txt_chiper->setText(QString::number(chiper));

}

void Dialog_2::on_konversi_2_clicked()
{

}

