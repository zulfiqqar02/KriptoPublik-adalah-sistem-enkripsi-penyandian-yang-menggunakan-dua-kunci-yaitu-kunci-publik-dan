#ifndef HOME_H
#define HOME_H

#include <QMainWindow>
#include "dialog_2.h"
#include "dialog_3.h"

QT_BEGIN_NAMESPACE
namespace Ui { class Home; }
QT_END_NAMESPACE

class Home : public QMainWindow
{
    Q_OBJECT

public:
    Home(QWidget *parent = nullptr);
    ~Home();

private slots:
    void on_btn_pengirim_clicked();

    void on_btn_penerima_clicked();

private:
    Ui::Home *ui;
    Dialog_2 *DIALOG_2;
    Dialog_3 *DIALOG_3;

};
#endif // HOME_H
