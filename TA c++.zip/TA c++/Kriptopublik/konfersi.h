#ifndef KONFERSI_H
#define KONFERSI_H


class Konfersi
{
public:
    Konfersi();
};

#endif // KONFERSI_H
