#include "dialog_3.h"
#include "ui_dialog_3.h"

Dialog_3::Dialog_3(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Dialog_3)
{
    ui->setupUi(this);
}

Dialog_3::~Dialog_3()
{
    delete ui;
}

//Digunakan untuk menghitung kunci publik penerima
void Dialog_3::on_pushButton_clicked()
{
    long int hasil = 1;
    long int pemodulo_2, pengirim_2;
    int angka1 = ui->g2->text().toInt();
    int angka2 = ui->private2->text().toInt();
    for (int i = 1; i <= angka2; i++) {
                hasil = hasil * angka1;
            }
    pemodulo_2 = ui->pemodulo2->text().toInt();
    pengirim_2 = hasil % pemodulo_2;
    ui->publikB2->setText(QString::number(pengirim_2));
}

//Digunakan untuk menghitung kunci deskripsi
void Dialog_3::on_pushButton_2_clicked()
{
    long int penerima_2,key_2,pemodulo_2;
    long int deskripsi = 1;
    int privat2 = ui->private2->text().toInt();
    penerima_2 = ui->publikA2->text().toInt();
    pemodulo_2 = ui->pemodulo2->text().toInt();


    for (int j = 1; j<= privat2; j++) {
         deskripsi = deskripsi * penerima_2;
    }

    key_2 = deskripsi % pemodulo_2;
    ui->key2->setText(QString::number(key_2));
}

//Digunakan untuk konversi karakter "chiper" kedalam ASCII
void Dialog_3::on_pushButton_4_clicked()
{
    QString chiper = ui->chiper2->text();
    QStringList numberString;
    for (const auto character:chiper){
        numberString << QString::number(character.unicode());
    }
    QString HexStrData = numberString.join(" ");
    ui->ascii2->setText(HexStrData);
}

//Digunakan untuk proses XOR antara Chiperteks dengan Kunci deskripsinya
void Dialog_3::on_pushButton_5_clicked()
{
    long int kripsi =1;
    int key_2 = ui->key2->text().toInt();
    int ascii_2 = ui->ascii2->text().toInt();

    kripsi = ascii_2 ^ key_2;
    ui->pesan2->setText(QString::number(kripsi));
}

void Dialog_3::on_pushButton_6_clicked()
{

}
