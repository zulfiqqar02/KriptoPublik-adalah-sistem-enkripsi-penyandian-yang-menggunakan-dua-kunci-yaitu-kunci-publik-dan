#include "dialog_3.h"
#include "ui_dialog_3.h"

Dialog_3::Dialog_3(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Dialog_3)
{
    ui->setupUi(this);
}

Dialog_3::~Dialog_3()
{
    delete ui;
}

//Menghitung kunci publik

void Dialog_3::on_pushButton_clicked()
{
    long int hasil = 1;
    long int pemodulo, penerima;
    int angka1 = ui->txt_g2->text().toInt();
    int angka2 = ui->txt_private2->text().toInt();
    for (int i = 1; i <= angka2; i++) {
                hasil = hasil * angka1;
            }
    pemodulo = ui->pemodulo2->text().toInt();
    penerima = hasil % pemodulo;
    ui->publikB2->setText(QString::number(penerima));
}

//Menghitung kunci deskripsi
void Dialog_3::on_pushButton_2_clicked()
{
    long int pengirim,key,pemodulo;
    long int deskrip = 1;
    int angka2 = ui->txt_private2->text().toInt();
    pengirim = ui->publikA2->text().toInt();
    pemodulo = ui->pemodulo2->text().toInt();


    for (int j = 1; j<= angka2; j++) {
         deskrip = deskrip * pengirim;
    }

    key = deskrip % pemodulo;
    ui->key2->setText(QString::number(key));
}

//Konversi kedalam ASCII
void Dialog_3::on_pushButton_4_clicked()
{
    QString chiper = ui->chiper2->text();
    QStringList numberString;
    for (const auto character:chiper){
        numberString << QString::number(character.unicode());
    }
    QString HexStrData = numberString.join(" ");
    ui->ascii2->setText(HexStrData);
}

//Proses Enkripsi
void Dialog_3::on_pushButton_5_clicked()
{
    long int pesan =1;
    int key = ui->key2->text().toInt();
    int ascii = ui->ascii2->text().toInt();

    pesan = ascii ^ key;
    ui->pesan2->setText(QString::number(pesan));
}


