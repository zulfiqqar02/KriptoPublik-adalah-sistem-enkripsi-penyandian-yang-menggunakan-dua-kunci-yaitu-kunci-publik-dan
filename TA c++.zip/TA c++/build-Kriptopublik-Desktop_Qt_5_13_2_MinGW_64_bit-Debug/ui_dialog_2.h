/********************************************************************************
** Form generated from reading UI file 'dialog_2.ui'
**
** Created by: Qt User Interface Compiler version 5.13.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DIALOG_2_H
#define UI_DIALOG_2_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QFormLayout>
#include <QtWidgets/QFrame>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Dialog_2
{
public:
    QLabel *label;
    QWidget *formLayoutWidget;
    QFormLayout *formLayout;
    QLabel *label_2;
    QLabel *label_3;
    QLabel *label_4;
    QLineEdit *txt_angka1;
    QLineEdit *txt_angka2;
    QLineEdit *txt_pemodulo;
    QPushButton *hitung_publik;
    QFrame *line;
    QPushButton *hitung_key;
    QFrame *line_2;
    QPushButton *konversi;
    QWidget *layoutWidget;
    QHBoxLayout *horizontalLayout_5;
    QLabel *label_9;
    QLineEdit *txt_ascii;
    QPushButton *btn_enkrip;
    QWidget *layoutWidget_2;
    QHBoxLayout *horizontalLayout_6;
    QLabel *label_10;
    QLineEdit *txt_chiper;
    QWidget *layoutWidget1;
    QHBoxLayout *horizontalLayout;
    QLabel *label_5;
    QLineEdit *txt_pengirim;
    QWidget *layoutWidget2;
    QHBoxLayout *horizontalLayout_2;
    QLabel *label_6;
    QLineEdit *txt_penerima;
    QWidget *layoutWidget3;
    QHBoxLayout *horizontalLayout_3;
    QLabel *label_7;
    QLineEdit *txt_key;
    QWidget *layoutWidget4;
    QHBoxLayout *horizontalLayout_4;
    QLabel *label_8;
    QLineEdit *txt_pesan;
    QPushButton *pushButton_7;

    void setupUi(QDialog *Dialog_2)
    {
        if (Dialog_2->objectName().isEmpty())
            Dialog_2->setObjectName(QString::fromUtf8("Dialog_2"));
        Dialog_2->resize(400, 502);
        label = new QLabel(Dialog_2);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(130, 0, 161, 21));
        QFont font;
        font.setFamily(QString::fromUtf8("Rockwell"));
        font.setPointSize(14);
        font.setBold(true);
        font.setItalic(true);
        font.setWeight(75);
        label->setFont(font);
        formLayoutWidget = new QWidget(Dialog_2);
        formLayoutWidget->setObjectName(QString::fromUtf8("formLayoutWidget"));
        formLayoutWidget->setGeometry(QRect(49, 30, 311, 111));
        formLayout = new QFormLayout(formLayoutWidget);
        formLayout->setObjectName(QString::fromUtf8("formLayout"));
        formLayout->setContentsMargins(0, 0, 0, 0);
        label_2 = new QLabel(formLayoutWidget);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        formLayout->setWidget(0, QFormLayout::LabelRole, label_2);

        label_3 = new QLabel(formLayoutWidget);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        formLayout->setWidget(1, QFormLayout::LabelRole, label_3);

        label_4 = new QLabel(formLayoutWidget);
        label_4->setObjectName(QString::fromUtf8("label_4"));

        formLayout->setWidget(2, QFormLayout::LabelRole, label_4);

        txt_angka1 = new QLineEdit(formLayoutWidget);
        txt_angka1->setObjectName(QString::fromUtf8("txt_angka1"));

        formLayout->setWidget(0, QFormLayout::FieldRole, txt_angka1);

        txt_angka2 = new QLineEdit(formLayoutWidget);
        txt_angka2->setObjectName(QString::fromUtf8("txt_angka2"));

        formLayout->setWidget(1, QFormLayout::FieldRole, txt_angka2);

        txt_pemodulo = new QLineEdit(formLayoutWidget);
        txt_pemodulo->setObjectName(QString::fromUtf8("txt_pemodulo"));

        formLayout->setWidget(2, QFormLayout::FieldRole, txt_pemodulo);

        hitung_publik = new QPushButton(Dialog_2);
        hitung_publik->setObjectName(QString::fromUtf8("hitung_publik"));
        hitung_publik->setGeometry(QRect(280, 110, 75, 31));
        line = new QFrame(Dialog_2);
        line->setObjectName(QString::fromUtf8("line"));
        line->setGeometry(QRect(50, 170, 311, 16));
        line->setFrameShape(QFrame::HLine);
        line->setFrameShadow(QFrame::Sunken);
        hitung_key = new QPushButton(Dialog_2);
        hitung_key->setObjectName(QString::fromUtf8("hitung_key"));
        hitung_key->setGeometry(QRect(280, 210, 75, 31));
        line_2 = new QFrame(Dialog_2);
        line_2->setObjectName(QString::fromUtf8("line_2"));
        line_2->setGeometry(QRect(50, 270, 311, 20));
        line_2->setFrameShape(QFrame::HLine);
        line_2->setFrameShadow(QFrame::Sunken);
        konversi = new QPushButton(Dialog_2);
        konversi->setObjectName(QString::fromUtf8("konversi"));
        konversi->setGeometry(QRect(280, 310, 75, 31));
        layoutWidget = new QWidget(Dialog_2);
        layoutWidget->setObjectName(QString::fromUtf8("layoutWidget"));
        layoutWidget->setGeometry(QRect(50, 340, 311, 34));
        horizontalLayout_5 = new QHBoxLayout(layoutWidget);
        horizontalLayout_5->setObjectName(QString::fromUtf8("horizontalLayout_5"));
        horizontalLayout_5->setContentsMargins(0, 0, 0, 0);
        label_9 = new QLabel(layoutWidget);
        label_9->setObjectName(QString::fromUtf8("label_9"));

        horizontalLayout_5->addWidget(label_9);

        txt_ascii = new QLineEdit(layoutWidget);
        txt_ascii->setObjectName(QString::fromUtf8("txt_ascii"));

        horizontalLayout_5->addWidget(txt_ascii);

        btn_enkrip = new QPushButton(Dialog_2);
        btn_enkrip->setObjectName(QString::fromUtf8("btn_enkrip"));
        btn_enkrip->setGeometry(QRect(280, 370, 75, 23));
        layoutWidget_2 = new QWidget(Dialog_2);
        layoutWidget_2->setObjectName(QString::fromUtf8("layoutWidget_2"));
        layoutWidget_2->setGeometry(QRect(50, 390, 311, 34));
        horizontalLayout_6 = new QHBoxLayout(layoutWidget_2);
        horizontalLayout_6->setObjectName(QString::fromUtf8("horizontalLayout_6"));
        horizontalLayout_6->setContentsMargins(0, 0, 0, 0);
        label_10 = new QLabel(layoutWidget_2);
        label_10->setObjectName(QString::fromUtf8("label_10"));

        horizontalLayout_6->addWidget(label_10);

        txt_chiper = new QLineEdit(layoutWidget_2);
        txt_chiper->setObjectName(QString::fromUtf8("txt_chiper"));

        horizontalLayout_6->addWidget(txt_chiper);

        layoutWidget1 = new QWidget(Dialog_2);
        layoutWidget1->setObjectName(QString::fromUtf8("layoutWidget1"));
        layoutWidget1->setGeometry(QRect(50, 140, 311, 34));
        horizontalLayout = new QHBoxLayout(layoutWidget1);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        label_5 = new QLabel(layoutWidget1);
        label_5->setObjectName(QString::fromUtf8("label_5"));

        horizontalLayout->addWidget(label_5);

        txt_pengirim = new QLineEdit(layoutWidget1);
        txt_pengirim->setObjectName(QString::fromUtf8("txt_pengirim"));

        horizontalLayout->addWidget(txt_pengirim);

        layoutWidget2 = new QWidget(Dialog_2);
        layoutWidget2->setObjectName(QString::fromUtf8("layoutWidget2"));
        layoutWidget2->setGeometry(QRect(50, 180, 311, 34));
        horizontalLayout_2 = new QHBoxLayout(layoutWidget2);
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        horizontalLayout_2->setContentsMargins(0, 0, 0, 0);
        label_6 = new QLabel(layoutWidget2);
        label_6->setObjectName(QString::fromUtf8("label_6"));

        horizontalLayout_2->addWidget(label_6);

        txt_penerima = new QLineEdit(layoutWidget2);
        txt_penerima->setObjectName(QString::fromUtf8("txt_penerima"));

        horizontalLayout_2->addWidget(txt_penerima);

        layoutWidget3 = new QWidget(Dialog_2);
        layoutWidget3->setObjectName(QString::fromUtf8("layoutWidget3"));
        layoutWidget3->setGeometry(QRect(50, 240, 311, 34));
        horizontalLayout_3 = new QHBoxLayout(layoutWidget3);
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        horizontalLayout_3->setContentsMargins(0, 0, 0, 0);
        label_7 = new QLabel(layoutWidget3);
        label_7->setObjectName(QString::fromUtf8("label_7"));

        horizontalLayout_3->addWidget(label_7);

        txt_key = new QLineEdit(layoutWidget3);
        txt_key->setObjectName(QString::fromUtf8("txt_key"));

        horizontalLayout_3->addWidget(txt_key);

        layoutWidget4 = new QWidget(Dialog_2);
        layoutWidget4->setObjectName(QString::fromUtf8("layoutWidget4"));
        layoutWidget4->setGeometry(QRect(50, 280, 311, 34));
        horizontalLayout_4 = new QHBoxLayout(layoutWidget4);
        horizontalLayout_4->setObjectName(QString::fromUtf8("horizontalLayout_4"));
        horizontalLayout_4->setContentsMargins(0, 0, 0, 0);
        label_8 = new QLabel(layoutWidget4);
        label_8->setObjectName(QString::fromUtf8("label_8"));

        horizontalLayout_4->addWidget(label_8);

        txt_pesan = new QLineEdit(layoutWidget4);
        txt_pesan->setObjectName(QString::fromUtf8("txt_pesan"));

        horizontalLayout_4->addWidget(txt_pesan);

        pushButton_7 = new QPushButton(Dialog_2);
        pushButton_7->setObjectName(QString::fromUtf8("pushButton_7"));
        pushButton_7->setGeometry(QRect(50, 440, 311, 31));

        retranslateUi(Dialog_2);
        QObject::connect(pushButton_7, SIGNAL(clicked()), txt_chiper, SLOT(clear()));
        QObject::connect(pushButton_7, SIGNAL(clicked()), txt_ascii, SLOT(clear()));
        QObject::connect(pushButton_7, SIGNAL(clicked()), txt_pesan, SLOT(clear()));
        QObject::connect(pushButton_7, SIGNAL(clicked()), txt_key, SLOT(clear()));
        QObject::connect(pushButton_7, SIGNAL(clicked()), txt_penerima, SLOT(clear()));
        QObject::connect(pushButton_7, SIGNAL(clicked()), txt_pengirim, SLOT(clear()));
        QObject::connect(pushButton_7, SIGNAL(clicked()), txt_pemodulo, SLOT(clear()));
        QObject::connect(pushButton_7, SIGNAL(clicked()), txt_angka2, SLOT(clear()));
        QObject::connect(pushButton_7, SIGNAL(clicked()), txt_angka1, SLOT(clear()));

        QMetaObject::connectSlotsByName(Dialog_2);
    } // setupUi

    void retranslateUi(QDialog *Dialog_2)
    {
        Dialog_2->setWindowTitle(QCoreApplication::translate("Dialog_2", "Dialog", nullptr));
        label->setText(QCoreApplication::translate("Dialog_2", "Kripto Publik (A)", nullptr));
        label_2->setText(QCoreApplication::translate("Dialog_2", "Masukkan G   ", nullptr));
        label_3->setText(QCoreApplication::translate("Dialog_2", "Private         ", nullptr));
        label_4->setText(QCoreApplication::translate("Dialog_2", "Pemodulo      ", nullptr));
        hitung_publik->setText(QCoreApplication::translate("Dialog_2", "Hitung", nullptr));
        hitung_key->setText(QCoreApplication::translate("Dialog_2", "Hitung Key", nullptr));
        konversi->setText(QCoreApplication::translate("Dialog_2", "Konversi", nullptr));
        label_9->setText(QCoreApplication::translate("Dialog_2", "ASCII            ", nullptr));
        btn_enkrip->setText(QCoreApplication::translate("Dialog_2", "Enkrip", nullptr));
        label_10->setText(QCoreApplication::translate("Dialog_2", "Hasil             ", nullptr));
        label_5->setText(QCoreApplication::translate("Dialog_2", "Kunci Publik A", nullptr));
        label_6->setText(QCoreApplication::translate("Dialog_2", "Kunci Publik B", nullptr));
        label_7->setText(QCoreApplication::translate("Dialog_2", "Key               ", nullptr));
        label_8->setText(QCoreApplication::translate("Dialog_2", "Pesan            ", nullptr));
        pushButton_7->setText(QCoreApplication::translate("Dialog_2", "Reset Pesan", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Dialog_2: public Ui_Dialog_2 {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DIALOG_2_H
