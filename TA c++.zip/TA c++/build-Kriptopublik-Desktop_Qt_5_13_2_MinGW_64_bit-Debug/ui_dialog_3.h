/********************************************************************************
** Form generated from reading UI file 'dialog_3.ui'
**
** Created by: Qt User Interface Compiler version 5.13.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DIALOG_3_H
#define UI_DIALOG_3_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QFormLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Dialog_3
{
public:
    QLabel *label;
    QWidget *layoutWidget;
    QFormLayout *formLayout;
    QLabel *label_2;
    QLineEdit *g2;
    QLabel *label_3;
    QLineEdit *private2;
    QLabel *label_4;
    QLineEdit *pemodulo2;
    QWidget *layoutWidget1;
    QVBoxLayout *verticalLayout;
    QPushButton *pushButton;
    QHBoxLayout *horizontalLayout;
    QLabel *label_5;
    QLineEdit *publikB2;
    QHBoxLayout *horizontalLayout_2;
    QLabel *label_6;
    QLineEdit *publikA2;
    QPushButton *pushButton_2;
    QHBoxLayout *horizontalLayout_3;
    QLabel *label_7;
    QLineEdit *key2;
    QHBoxLayout *horizontalLayout_4;
    QLabel *label_8;
    QLineEdit *chiper2;
    QPushButton *pushButton_4;
    QHBoxLayout *horizontalLayout_5;
    QLabel *label_9;
    QLineEdit *ascii2;
    QPushButton *pushButton_5;
    QHBoxLayout *horizontalLayout_6;
    QLabel *label_10;
    QLineEdit *pesan2;
    QPushButton *konversi_2;
    QPushButton *pushButton_7;

    void setupUi(QDialog *Dialog_3)
    {
        if (Dialog_3->objectName().isEmpty())
            Dialog_3->setObjectName(QString::fromUtf8("Dialog_3"));
        Dialog_3->resize(379, 521);
        label = new QLabel(Dialog_3);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(100, 20, 171, 16));
        QFont font;
        font.setFamily(QString::fromUtf8("Rockwell"));
        font.setPointSize(16);
        font.setBold(true);
        font.setItalic(true);
        font.setWeight(75);
        label->setFont(font);
        layoutWidget = new QWidget(Dialog_3);
        layoutWidget->setObjectName(QString::fromUtf8("layoutWidget"));
        layoutWidget->setGeometry(QRect(30, 50, 311, 74));
        formLayout = new QFormLayout(layoutWidget);
        formLayout->setObjectName(QString::fromUtf8("formLayout"));
        formLayout->setContentsMargins(0, 0, 0, 0);
        label_2 = new QLabel(layoutWidget);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        formLayout->setWidget(0, QFormLayout::LabelRole, label_2);

        g2 = new QLineEdit(layoutWidget);
        g2->setObjectName(QString::fromUtf8("g2"));

        formLayout->setWidget(0, QFormLayout::FieldRole, g2);

        label_3 = new QLabel(layoutWidget);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        formLayout->setWidget(1, QFormLayout::LabelRole, label_3);

        private2 = new QLineEdit(layoutWidget);
        private2->setObjectName(QString::fromUtf8("private2"));

        formLayout->setWidget(1, QFormLayout::FieldRole, private2);

        label_4 = new QLabel(layoutWidget);
        label_4->setObjectName(QString::fromUtf8("label_4"));

        formLayout->setWidget(2, QFormLayout::LabelRole, label_4);

        pemodulo2 = new QLineEdit(layoutWidget);
        pemodulo2->setObjectName(QString::fromUtf8("pemodulo2"));

        formLayout->setWidget(2, QFormLayout::FieldRole, pemodulo2);

        layoutWidget1 = new QWidget(Dialog_3);
        layoutWidget1->setObjectName(QString::fromUtf8("layoutWidget1"));
        layoutWidget1->setGeometry(QRect(30, 140, 311, 324));
        verticalLayout = new QVBoxLayout(layoutWidget1);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        pushButton = new QPushButton(layoutWidget1);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));

        verticalLayout->addWidget(pushButton);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        label_5 = new QLabel(layoutWidget1);
        label_5->setObjectName(QString::fromUtf8("label_5"));

        horizontalLayout->addWidget(label_5);

        publikB2 = new QLineEdit(layoutWidget1);
        publikB2->setObjectName(QString::fromUtf8("publikB2"));

        horizontalLayout->addWidget(publikB2);


        verticalLayout->addLayout(horizontalLayout);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        label_6 = new QLabel(layoutWidget1);
        label_6->setObjectName(QString::fromUtf8("label_6"));

        horizontalLayout_2->addWidget(label_6);

        publikA2 = new QLineEdit(layoutWidget1);
        publikA2->setObjectName(QString::fromUtf8("publikA2"));

        horizontalLayout_2->addWidget(publikA2);


        verticalLayout->addLayout(horizontalLayout_2);

        pushButton_2 = new QPushButton(layoutWidget1);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));

        verticalLayout->addWidget(pushButton_2);

        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        label_7 = new QLabel(layoutWidget1);
        label_7->setObjectName(QString::fromUtf8("label_7"));

        horizontalLayout_3->addWidget(label_7);

        key2 = new QLineEdit(layoutWidget1);
        key2->setObjectName(QString::fromUtf8("key2"));

        horizontalLayout_3->addWidget(key2);


        verticalLayout->addLayout(horizontalLayout_3);

        horizontalLayout_4 = new QHBoxLayout();
        horizontalLayout_4->setObjectName(QString::fromUtf8("horizontalLayout_4"));
        label_8 = new QLabel(layoutWidget1);
        label_8->setObjectName(QString::fromUtf8("label_8"));

        horizontalLayout_4->addWidget(label_8);

        chiper2 = new QLineEdit(layoutWidget1);
        chiper2->setObjectName(QString::fromUtf8("chiper2"));

        horizontalLayout_4->addWidget(chiper2);


        verticalLayout->addLayout(horizontalLayout_4);

        pushButton_4 = new QPushButton(layoutWidget1);
        pushButton_4->setObjectName(QString::fromUtf8("pushButton_4"));

        verticalLayout->addWidget(pushButton_4);

        horizontalLayout_5 = new QHBoxLayout();
        horizontalLayout_5->setObjectName(QString::fromUtf8("horizontalLayout_5"));
        label_9 = new QLabel(layoutWidget1);
        label_9->setObjectName(QString::fromUtf8("label_9"));

        horizontalLayout_5->addWidget(label_9);

        ascii2 = new QLineEdit(layoutWidget1);
        ascii2->setObjectName(QString::fromUtf8("ascii2"));

        horizontalLayout_5->addWidget(ascii2);


        verticalLayout->addLayout(horizontalLayout_5);

        pushButton_5 = new QPushButton(layoutWidget1);
        pushButton_5->setObjectName(QString::fromUtf8("pushButton_5"));

        verticalLayout->addWidget(pushButton_5);

        horizontalLayout_6 = new QHBoxLayout();
        horizontalLayout_6->setObjectName(QString::fromUtf8("horizontalLayout_6"));
        label_10 = new QLabel(layoutWidget1);
        label_10->setObjectName(QString::fromUtf8("label_10"));

        horizontalLayout_6->addWidget(label_10);

        pesan2 = new QLineEdit(layoutWidget1);
        pesan2->setObjectName(QString::fromUtf8("pesan2"));

        horizontalLayout_6->addWidget(pesan2);


        verticalLayout->addLayout(horizontalLayout_6);

        konversi_2 = new QPushButton(Dialog_3);
        konversi_2->setObjectName(QString::fromUtf8("konversi_2"));
        konversi_2->setGeometry(QRect(559, 869, 75, 31));
        pushButton_7 = new QPushButton(Dialog_3);
        pushButton_7->setObjectName(QString::fromUtf8("pushButton_7"));
        pushButton_7->setGeometry(QRect(30, 470, 311, 31));

        retranslateUi(Dialog_3);
        QObject::connect(pushButton_7, SIGNAL(clicked()), pesan2, SLOT(clear()));
        QObject::connect(pushButton_7, SIGNAL(clicked()), ascii2, SLOT(clear()));
        QObject::connect(pushButton_7, SIGNAL(clicked()), chiper2, SLOT(clear()));
        QObject::connect(pushButton_7, SIGNAL(clicked()), key2, SLOT(clear()));
        QObject::connect(pushButton_7, SIGNAL(clicked()), publikA2, SLOT(clear()));
        QObject::connect(pushButton_7, SIGNAL(clicked()), publikB2, SLOT(clear()));
        QObject::connect(pushButton_7, SIGNAL(clicked()), pemodulo2, SLOT(clear()));
        QObject::connect(pushButton_7, SIGNAL(clicked()), private2, SLOT(clear()));
        QObject::connect(pushButton_7, SIGNAL(clicked()), g2, SLOT(clear()));

        QMetaObject::connectSlotsByName(Dialog_3);
    } // setupUi

    void retranslateUi(QDialog *Dialog_3)
    {
        Dialog_3->setWindowTitle(QCoreApplication::translate("Dialog_3", "Dialog", nullptr));
        label->setText(QCoreApplication::translate("Dialog_3", "Kripto Publik B", nullptr));
        label_2->setText(QCoreApplication::translate("Dialog_3", "g", nullptr));
        label_3->setText(QCoreApplication::translate("Dialog_3", "Private", nullptr));
        label_4->setText(QCoreApplication::translate("Dialog_3", "Pemodulo", nullptr));
        pushButton->setText(QCoreApplication::translate("Dialog_3", "Hitung", nullptr));
        label_5->setText(QCoreApplication::translate("Dialog_3", "Kunci Publk B", nullptr));
        label_6->setText(QCoreApplication::translate("Dialog_3", "Kunci Publik A", nullptr));
        pushButton_2->setText(QCoreApplication::translate("Dialog_3", "Hitung key", nullptr));
        label_7->setText(QCoreApplication::translate("Dialog_3", "key", nullptr));
        label_8->setText(QCoreApplication::translate("Dialog_3", "Chiper", nullptr));
        pushButton_4->setText(QCoreApplication::translate("Dialog_3", "konversi", nullptr));
        label_9->setText(QCoreApplication::translate("Dialog_3", "Ascii", nullptr));
        pushButton_5->setText(QCoreApplication::translate("Dialog_3", "deskrip", nullptr));
        label_10->setText(QCoreApplication::translate("Dialog_3", "Pesan", nullptr));
        konversi_2->setText(QCoreApplication::translate("Dialog_3", "Konversi", nullptr));
        pushButton_7->setText(QCoreApplication::translate("Dialog_3", "Reset Pesan", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Dialog_3: public Ui_Dialog_3 {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DIALOG_3_H
